package com.sovos.coupa.domain;

public class Solution {
    private String id;
    private String gtdUsername;
    private String gtdOrgCode;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getGtdUsername() {
        return gtdUsername;
    }

    public void setGtdUsername(String gtdUsername) {
        this.gtdUsername = gtdUsername;
    }

    public String getGtdOrgCode() {
        return gtdOrgCode;
    }

    public void setGtdOrgCode(String gtdOrgCode) {
        this.gtdOrgCode = gtdOrgCode;
    }

}
