package com.sovos.coupa.controller.dto;

import io.swagger.v3.oas.annotations.media.Schema;

public class CustomFieldsLineItemGtdRequest {

	@Schema
	private String SOVOS_CA_1;

	public String get_custom_field_1() {
		return SOVOS_CA_1;
	}

	public void set_custom_field_1(String custom_field_1) {
		this.SOVOS_CA_1 = custom_field_1;
	}

	@Schema
	private String SOVOS_CA_2;

	public String get_custom_field_2() {
		return SOVOS_CA_2;
	}

	public void set_custom_field_2(String custom_field_2) {
		this.SOVOS_CA_2 = custom_field_2;
	}

	@Schema
	private String SOVOS_CA_3;

	public String get_custom_field_3() {
		return SOVOS_CA_3;
	}

	public void set_custom_field_3(String custom_field_3) {
		this.SOVOS_CA_3 = custom_field_3;
	}

	@Schema
	private String SOVOS_CA_4;

	public String get_custom_field_4() {
		return SOVOS_CA_4;
	}

	public void set_custom_field_4(String custom_field_4) {
		this.SOVOS_CA_4 = custom_field_4;
	}

	@Schema
	private String SOVOS_CA_5;

	public String get_custom_field_5() {
		return SOVOS_CA_5;
	}

	public void set_custom_field_5(String custom_field_5) {
		this.SOVOS_CA_5 = custom_field_5;
	}

	@Schema
	private String SOVOS_CA_6;

	public String get_custom_field_6() {
		return SOVOS_CA_6;
	}

	public void set_custom_field_6(String custom_field_6) {
		this.SOVOS_CA_6 = custom_field_6;
	}

	@Schema
	private String SOVOS_CA_7;

	public String get_custom_field_7() {
		return SOVOS_CA_7;
	}

	public void set_custom_field_7(String custom_field_7) {
		this.SOVOS_CA_7 = custom_field_7;
	}

	@Schema
	private String SOVOS_CA_8;

	public String get_custom_field_8() {
		return SOVOS_CA_8;
	}

	public void set_custom_field_8(String custom_field_8) {
		this.SOVOS_CA_8 = custom_field_8;
	}

	@Schema
	private String SOVOS_CA_9;

	public String get_custom_field_9() {
		return SOVOS_CA_9;
	}

	public void set_custom_field_9(String custom_field_9) {
		this.SOVOS_CA_9 = custom_field_9;
	}

	@Schema
	private String SOVOS_CA_10;

	public String get_custom_field_10() {
		return SOVOS_CA_10;
	}

	public void set_custom_field_10(String custom_field_10) {
		this.SOVOS_CA_10 = custom_field_10;
	}
}
